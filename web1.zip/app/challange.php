<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class challange extends Model
{
    //
}
